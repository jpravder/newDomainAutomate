__author__ = 'Rustem Sayargaliev'

__version__ = '1.0.1'
